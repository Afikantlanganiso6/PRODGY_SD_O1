﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareDeve_Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void buttonConvert_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(textBoxTemperature.Text, out double inputTemperature))
            {
                MessageBox.Show("Please enter a valid temperature value.");
                return;
            }

            double celsius, fahrenheit, kelvin;

            if (radioButtonCelsius.Checked)
            {
                celsius = inputTemperature;
                fahrenheit = (celsius * 9 / 5) + 32;
                kelvin = celsius + 273.15;
            }
            else if (radioButtonFahrenheit.Checked)
            {
                fahrenheit = inputTemperature;
                celsius = (fahrenheit - 32) * 5 / 9;
                kelvin = celsius + 273.15;
            }
            else if (radioButtonKelvin.Checked)
            {
                kelvin = inputTemperature;
                celsius = kelvin - 273.15;
                fahrenheit = (celsius * 9 / 5) + 32;
            }
            else
            {
                MessageBox.Show("Please select a unit of measurement.");
                return;
            }

            labelCelsius.Text = $"Celsius: {celsius:F2} °C";
            labelFahrenheit.Text = $"Fahrenheit: {fahrenheit:F2} °F";
            labelKelvin.Text = $"Kelvin: {kelvin:F2} K";
        }
    }
}
